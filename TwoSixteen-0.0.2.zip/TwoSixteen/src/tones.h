
#ifdef __cplusplus
extern "C" {
#endif

  void init_speaker();
  void speaker_tone(unsigned int frequency, unsigned long duration);

#ifdef __cplusplus
}
#endif


